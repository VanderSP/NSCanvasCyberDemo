import { Application } from "@nativescript/core";

require("@nativescript/canvas-polyfill");

Application.run({ moduleName: "app-root" });
